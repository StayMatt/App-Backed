package com.JulcamoroTucto.service;

import com.JulcamoroTucto.model.Curso;
import java.util.List;

public interface ICursoService extends IGenSer<Curso,Integer> {

}