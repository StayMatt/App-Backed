package com.JulcamoroTucto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdusyncappBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdusyncappBackendApplication.class, args);
	}

	

}
