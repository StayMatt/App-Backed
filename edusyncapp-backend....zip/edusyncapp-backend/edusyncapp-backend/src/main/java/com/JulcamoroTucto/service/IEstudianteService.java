package com.JulcamoroTucto.service;

import com.JulcamoroTucto.model.Estudiante;
import java.util.List;

public interface IEstudianteService extends IGenSer<Estudiante, Integer> {

}