package com.JulcamoroTucto.repository;

import com.JulcamoroTucto.model.Estudiante;

public interface IEstudianteRepo extends IGeneRepo<Estudiante, Integer> {
}
