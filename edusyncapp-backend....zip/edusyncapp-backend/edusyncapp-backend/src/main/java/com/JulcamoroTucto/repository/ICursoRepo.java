package com.JulcamoroTucto.repository;

import com.JulcamoroTucto.model.Curso;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ICursoRepo extends IGeneRepo<Curso, Integer> {

}