package com.JulcamoroTucto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdusyncappBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
